export interface Ticket {
  id: number;
  userId: number;
  quantity: number;
}